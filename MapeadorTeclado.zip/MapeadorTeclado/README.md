# Mapeador Teclado e Mouse (Android)

Converte teclas de um teclado físico (USB-OTG/Bluetooth) em toques na tela do celular,
com botões e joystick virtual (WASD). Usa um Serviço de Acessibilidade.

## Gerar o APK

**Opção A — GitHub (sem instalar nada):**
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (incluindo `.github/`).
2. Aba **Actions** → **Build APK** → rode (ou aguarde o push disparar).
3. Ao terminar, baixe o artefato **MapeadorTeclado-apk** (contém `app-debug.apk`).

**Opção B — Android Studio:** abra a pasta e use *Build > Build APK(s)*.

**Opção C — terminal** (JDK 17 + Android SDK + Gradle 8.7): `gradle assembleDebug`
→ `app/build/outputs/apk/debug/app-debug.apk`

## Instalar
Permita "instalar apps desconhecidos" e abra o `.apk`. Depois ative o serviço em
*Configurações > Acessibilidade*.

## Usar
1. Abra o app e ative o serviço. Aparece um botão flutuante **KM**.
2. Abra o jogo. **Segure KM** (1 s) para abrir o editor.
3. Toque no ponto da tela e pressione a tecla que deve acioná-lo. Para movimento,
   mude para **JOYSTICK**, toque no centro do joystick do jogo e pressione 4 teclas.
4. **Toque em KM** ou aperte **F8** para ligar/desligar o modo jogo.

## Limitações
- Cliques esquerdo/direito e movimento do mouse não são interceptados (limite do Android
  para serviços de acessibilidade). Botões laterais do mouse funcionam como teclas.
- Latência de ~50 ms; mapeamentos valem para a orientação em que foram criados.
- Código não foi compilado nem testado em aparelho real antes da entrega.
