package br.mapeador.teclado;

/** Um mapeamento: tecla(s) do teclado -> ponto de toque na tela. */
public class Mapping {
    public static final int BOTAO = 0;
    public static final int JOYSTICK = 1;

    public int type = BOTAO;
    public float x;
    public float y;
    public int radius = 150;

    /** BOTAO: keys[0]. JOYSTICK: cima, esquerda, baixo, direita. */
    public int[] keys = new int[4];

    /** Estado em memória das 4 direções do joystick (não é salvo). */
    public final boolean[] held = new boolean[4];
}
