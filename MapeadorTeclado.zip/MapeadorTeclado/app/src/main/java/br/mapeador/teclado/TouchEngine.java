package br.mapeador.teclado;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Converte "tecla pressionada / solta" em dedos virtuais na tela.
 *
 * O Android cancela qualquer gesto em andamento quando outro é enviado. Por isso
 * todos os dedos ativos (joystick + botões) vão juntos em UM gesto de vários
 * traços, em segmentos curtos encadeados com continueStroke(). Mudanças
 * (apertar/soltar) entram no próximo segmento (~50 ms de latência).
 */
class TouchEngine {
    private static final long SEG_MS = 50;

    private static class Slot {
        float sx, sy;   // onde o dedo encosta (início)
        float tx, ty;   // para onde o dedo deve ir
        float x, y;     // onde o dedo está agora
        boolean wantDown;
        boolean minHold;    // garante ao menos 1 segmento mesmo em toque muito rápido
        boolean down;       // há um traço "em andamento" (willContinue)
        GestureDescription.StrokeDescription stroke;
    }

    private final AccessibilityService svc;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, Slot> slots = new LinkedHashMap<>();
    private boolean busy;

    TouchEngine(AccessibilityService svc) {
        this.svc = svc;
    }

    /** Aperta (ou atualiza o alvo de) um dedo virtual. */
    void press(String id, float sx, float sy, float tx, float ty) {
        Slot s = slots.get(id);
        if (s == null) {
            s = new Slot();
            slots.put(id, s);
        }
        if (!s.wantDown && !s.down) {
            s.sx = sx;
            s.sy = sy;
            s.minHold = true;
        }
        s.tx = tx;
        s.ty = ty;
        s.wantDown = true;
        pump();
    }

    void release(String id) {
        Slot s = slots.get(id);
        if (s != null) {
            s.wantDown = false;
            pump();
        }
    }

    void releaseAll() {
        for (Slot s : slots.values()) {
            s.wantDown = false;
        }
        pump();
    }

    private void resetDown() {
        for (Slot s : slots.values()) {
            s.down = false;
            s.stroke = null;
        }
    }

    private void pump() {
        if (busy) {
            return;
        }
        GestureDescription.Builder b = new GestureDescription.Builder();
        int n = 0;
        for (Slot s : slots.values()) {
            GestureDescription.StrokeDescription st = null;
            if (!s.down && (s.wantDown || s.minHold)) {
                Path p = new Path();
                p.moveTo(s.sx, s.sy);
                if (s.sx != s.tx || s.sy != s.ty) {
                    p.lineTo(s.tx, s.ty);
                }
                boolean cont = s.wantDown;
                st = new GestureDescription.StrokeDescription(p, 0, SEG_MS, cont);
                s.down = cont;
                s.minHold = false;
            } else if (s.down) {
                Path p = new Path();
                p.moveTo(s.x, s.y);
                if (s.x != s.tx || s.y != s.ty) {
                    p.lineTo(s.tx, s.ty);
                }
                boolean cont = s.wantDown;
                st = s.stroke.continueStroke(p, 0, SEG_MS, cont);
                s.down = cont;
            }
            if (st != null) {
                s.stroke = st;
                s.x = s.tx;
                s.y = s.ty;
                b.addStroke(st);
                n++;
            }
        }
        if (n == 0) {
            return;
        }
        busy = true;
        boolean ok = svc.dispatchGesture(b.build(), new AccessibilityService.GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                busy = false;
                pump();
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                busy = false;
                resetDown();
                pump();
            }
        }, main);
        if (!ok) {
            busy = false;
            resetDown();
        }
    }
}
