package br.mapeador.teclado;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MapperService extends AccessibilityService {

    static MapperService instance;

    List<Mapping> maps = new ArrayList<>();
    boolean gameMode = false;

    private TouchEngine engine;
    private WindowManager wm;
    private TextView bubble;
    private EditorOverlay editor;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        engine = new TouchEngine(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        maps = MappingStore.load(this);
        if (bubble == null) {
            createBubble();
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // não usado
    }

    @Override
    public void onInterrupt() {
        if (engine != null) {
            engine.releaseAll();
        }
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        closeEditor();
        if (bubble != null && wm != null) {
            try {
                wm.removeView(bubble);
            } catch (RuntimeException ignored) {
            }
            bubble = null;
        }
        if (engine != null) {
            engine.releaseAll();
        }
        instance = null;
        return super.onUnbind(intent);
    }

    // ---------------------------------------------------------------- teclas

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        int action = e.getAction();
        boolean first = action == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0;

        if (editor != null) {
            if (first) {
                editor.onKey(code);
            }
            return true;
        }
        if (code == KeyEvent.KEYCODE_F8) {
            if (first) {
                setGameMode(!gameMode);
            }
            return true;
        }
        if (!gameMode) {
            return false;
        }

        boolean handled = false;
        for (int i = 0; i < maps.size(); i++) {
            Mapping m = maps.get(i);
            String id = "m" + i;
            if (m.type == Mapping.BOTAO) {
                if (m.keys[0] != 0 && m.keys[0] == code) {
                    handled = true;
                    if (first) {
                        engine.press(id, m.x, m.y, m.x, m.y);
                    } else if (action == KeyEvent.ACTION_UP) {
                        engine.release(id);
                    }
                }
            } else {
                for (int d = 0; d < 4; d++) {
                    if (m.keys[d] != 0 && m.keys[d] == code) {
                        handled = true;
                        if (first) {
                            m.held[d] = true;
                        } else if (action == KeyEvent.ACTION_UP) {
                            m.held[d] = false;
                        } else {
                            continue;
                        }
                        updateJoystick(id, m);
                    }
                }
            }
        }
        return handled;
    }

    private void updateJoystick(String id, Mapping m) {
        int dx = (m.held[3] ? 1 : 0) - (m.held[1] ? 1 : 0);
        int dy = (m.held[2] ? 1 : 0) - (m.held[0] ? 1 : 0);
        if (dx == 0 && dy == 0) {
            engine.release(id);
            return;
        }
        double len = Math.sqrt(dx * dx + dy * dy);
        float tx = m.x + (float) (dx / len * m.radius);
        float ty = m.y + (float) (dy / len * m.radius);
        engine.press(id, m.x, m.y, tx, ty);
    }

    // ------------------------------------------------------------ modo jogo

    void setGameMode(boolean on) {
        gameMode = on;
        if (!on) {
            for (Mapping m : maps) {
                Arrays.fill(m.held, false);
            }
            engine.releaseAll();
        }
        paintBubble();
        Toast.makeText(this,
                on ? "Modo jogo LIGADO (F8 alterna)" : "Modo jogo desligado",
                Toast.LENGTH_SHORT).show();
    }

    // --------------------------------------------------------------- editor

    void openEditor() {
        if (editor != null) {
            return;
        }
        if (gameMode) {
            setGameMode(false);
        }
        editor = new EditorOverlay(this, maps);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(editor, lp);
    }

    void closeEditor() {
        if (editor == null) {
            return;
        }
        try {
            wm.removeView(editor);
        } catch (RuntimeException ignored) {
        }
        editor = null;
        MappingStore.save(this, maps);
    }

    // --------------------------------------------------------- botão flutuante

    private void paintBubble() {
        if (bubble == null) {
            return;
        }
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(gameMode ? 0xEE2E7D32 : 0xEE616161);
        g.setStroke(3, Color.WHITE);
        bubble.setBackground(g);
    }

    private void createBubble() {
        final float d = getResources().getDisplayMetrics().density;
        final TextView t = new TextView(this);
        t.setText("KM");
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        bubble = t;
        paintBubble();

        int size = (int) (46 * d);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (8 * d);
        lp.y = (int) (120 * d);

        t.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved, longFired;
            final Runnable longPress = new Runnable() {
                @Override
                public void run() {
                    if (!moved) {
                        longFired = true;
                        openEditor();
                    }
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = ev.getRawX();
                        downY = ev.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        longFired = false;
                        handler.postDelayed(longPress, 600);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float mx = ev.getRawX() - downX;
                        float my = ev.getRawY() - downY;
                        if (Math.abs(mx) > 12 * d || Math.abs(my) > 12 * d) {
                            moved = true;
                            handler.removeCallbacks(longPress);
                        }
                        if (moved) {
                            lp.x = startX + (int) mx;
                            lp.y = startY + (int) my;
                            wm.updateViewLayout(t, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        handler.removeCallbacks(longPress);
                        if (!moved && !longFired) {
                            setGameMode(!gameMode);
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(longPress);
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(t, lp);
    }
}
