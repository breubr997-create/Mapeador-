package br.mapeador.teclado;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Salva e carrega os mapeamentos em SharedPreferences (JSON). */
public final class MappingStore {
    private static final String PREFS = "mapeador";
    private static final String KEY = "maps";

    private MappingStore() {}

    public static List<Mapping> load(Context c) {
        List<Mapping> out = new ArrayList<>();
        String raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Mapping m = new Mapping();
                m.type = o.getInt("t");
                m.x = (float) o.getDouble("x");
                m.y = (float) o.getDouble("y");
                m.radius = o.optInt("r", 150);
                JSONArray k = o.getJSONArray("k");
                for (int j = 0; j < 4 && j < k.length(); j++) {
                    m.keys[j] = k.getInt(j);
                }
                out.add(m);
            }
        } catch (JSONException e) {
            out.clear();
        }
        return out;
    }

    public static void save(Context c, List<Mapping> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Mapping m : list) {
                JSONObject o = new JSONObject();
                o.put("t", m.type);
                o.put("x", (double) m.x);
                o.put("y", (double) m.y);
                o.put("r", m.radius);
                JSONArray k = new JSONArray();
                for (int v : m.keys) {
                    k.put(v);
                }
                o.put("k", k);
                arr.put(o);
            }
        } catch (JSONException e) {
            return;
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, arr.toString())
                .apply();
    }
}
