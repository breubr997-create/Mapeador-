package br.mapeador.teclado;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

/**
 * Tela de edição por cima do jogo: toque num ponto da tela e depois pressione a
 * tecla (ou botão lateral do mouse) que deve acionar esse ponto.
 */
class EditorOverlay extends FrameLayout {
    private static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final String[] DIR = {"CIMA", "ESQUERDA", "BAIXO", "DIREITA"};

    private final MapperService svc;
    private final List<Mapping> maps;
    private Board board;
    private TextView hint;
    private Button typeBtn;
    private Button radiusBtn;
    private float dens;

    private boolean joystick = false;
    private int radius = 150;
    private int step = 0; // 0 = aguardando posição; >=1 = aguardando tecla
    private float px;
    private float py;
    private final int[] keys = new int[4];

    EditorOverlay(MapperService svc, List<Mapping> maps) {
        super(svc);
        this.svc = svc;
        this.maps = maps;
        dens = getResources().getDisplayMetrics().density;

        board = new Board(svc);
        addView(board, new FrameLayout.LayoutParams(MP, MP));

        LinearLayout panel = new LinearLayout(svc);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(0xEE202020);
        int pad = (int) (8 * dens);
        panel.setPadding(pad, statusBarHeight() + pad, pad, pad);

        LinearLayout row = new LinearLayout(svc);
        row.setOrientation(LinearLayout.HORIZONTAL);

        typeBtn = mk("Tipo: BOTÃO", new OnClickListener() {
            @Override
            public void onClick(View v) {
                joystick = !joystick;
                step = 0;
                refresh();
            }
        });
        radiusBtn = mk("Raio: 150", new OnClickListener() {
            @Override
            public void onClick(View v) {
                radius = radius >= 250 ? 100 : radius + 50;
                refresh();
            }
        });
        Button undo = mk("Desfazer", new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!EditorOverlay.this.maps.isEmpty()) {
                    EditorOverlay.this.maps.remove(EditorOverlay.this.maps.size() - 1);
                    MappingStore.save(EditorOverlay.this.svc, EditorOverlay.this.maps);
                }
                step = 0;
                refresh();
            }
        });
        Button clear = mk("Limpar", new OnClickListener() {
            @Override
            public void onClick(View v) {
                EditorOverlay.this.maps.clear();
                MappingStore.save(EditorOverlay.this.svc, EditorOverlay.this.maps);
                step = 0;
                refresh();
            }
        });
        Button exit = mk("Salvar e sair", new OnClickListener() {
            @Override
            public void onClick(View v) {
                EditorOverlay.this.svc.closeEditor();
            }
        });

        row.addView(typeBtn, new LinearLayout.LayoutParams(0, WC, 1f));
        row.addView(radiusBtn, new LinearLayout.LayoutParams(0, WC, 1f));
        row.addView(undo, new LinearLayout.LayoutParams(0, WC, 1f));
        row.addView(clear, new LinearLayout.LayoutParams(0, WC, 1f));
        row.addView(exit, new LinearLayout.LayoutParams(0, WC, 1f));
        panel.addView(row, new LinearLayout.LayoutParams(MP, WC));

        hint = new TextView(svc);
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(14);
        hint.setPadding(0, pad, 0, 0);
        panel.addView(hint, new LinearLayout.LayoutParams(MP, WC));

        addView(panel, new FrameLayout.LayoutParams(MP, WC, Gravity.TOP));
        refresh();
    }

    private Button mk(String text, OnClickListener l) {
        Button b = new Button(getContext());
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setOnClickListener(l);
        return b;
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : (int) (24 * dens);
    }

    private void refresh() {
        typeBtn.setText(joystick ? "Tipo: JOYSTICK" : "Tipo: BOTÃO");
        radiusBtn.setText("Raio: " + radius);
        radiusBtn.setVisibility(joystick ? View.VISIBLE : View.GONE);
        String h;
        if (step == 0) {
            h = joystick
                    ? "Toque no CENTRO do joystick virtual do jogo."
                    : "Toque na tela onde fica o botão do jogo (ex.: atirar, pular).";
        } else if (!joystick) {
            h = "Agora pressione a tecla do teclado (ou botão lateral do mouse) para esse ponto.";
        } else {
            h = "Pressione a tecla para " + DIR[step - 1] + " (" + step + "/4).";
        }
        hint.setText(h);
        board.invalidate();
    }

    /** Chamado pelo serviço quando uma tecla é pressionada durante a edição. */
    void onKey(int code) {
        if (step == 0) {
            return;
        }
        if (!joystick) {
            Mapping m = new Mapping();
            m.type = Mapping.BOTAO;
            m.x = px;
            m.y = py;
            m.keys[0] = code;
            maps.add(m);
            MappingStore.save(svc, maps);
            step = 0;
        } else {
            keys[step - 1] = code;
            if (step == 4) {
                Mapping m = new Mapping();
                m.type = Mapping.JOYSTICK;
                m.x = px;
                m.y = py;
                m.radius = radius;
                System.arraycopy(keys, 0, m.keys, 0, 4);
                maps.add(m);
                MappingStore.save(svc, maps);
                step = 0;
            } else {
                step++;
            }
        }
        refresh();
    }

    static String label(int code) {
        if (code == 0) {
            return "?";
        }
        String s = KeyEvent.keyCodeToString(code);
        return s.startsWith("KEYCODE_") ? s.substring(8) : s;
    }

    /** Camada de desenho e captura de toque. */
    private class Board extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

        Board(Context c) {
            super(c);
            setBackgroundColor(0x88000000);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(3 * dens);
            text.setColor(Color.WHITE);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(11 * dens);
            text.setFakeBoldText(true);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                px = e.getRawX();
                py = e.getRawY();
                step = 1;
                Arrays.fill(keys, 0);
                refresh();
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int[] loc = new int[2];
            getLocationOnScreen(loc);
            float r = 26 * dens;
            for (Mapping m : maps) {
                float cx = m.x - loc[0];
                float cy = m.y - loc[1];
                if (m.type == Mapping.BOTAO) {
                    fill.setColor(0xAA00C853);
                    c.drawCircle(cx, cy, r, fill);
                    line.setColor(Color.WHITE);
                    c.drawCircle(cx, cy, r, line);
                    c.drawText(label(m.keys[0]), cx, cy + text.getTextSize() / 3, text);
                } else {
                    line.setColor(0xFF40C4FF);
                    c.drawCircle(cx, cy, m.radius, line);
                    fill.setColor(0xAA0091EA);
                    c.drawCircle(cx, cy, r / 2, fill);
                    c.drawText(label(m.keys[0]), cx, cy - m.radius - 6 * dens, text);
                    c.drawText(label(m.keys[1]), cx - m.radius - 6 * dens, cy + text.getTextSize() / 3, text);
                    c.drawText(label(m.keys[2]), cx, cy + m.radius + 16 * dens, text);
                    c.drawText(label(m.keys[3]), cx + m.radius + 6 * dens, cy + text.getTextSize() / 3, text);
                }
            }
            if (step > 0) {
                float cx = px - loc[0];
                float cy = py - loc[1];
                line.setColor(0xFFFFEB3B);
                c.drawCircle(cx, cy, r, line);
                c.drawLine(cx - r * 1.5f, cy, cx + r * 1.5f, cy, line);
                c.drawLine(cx, cy - r * 1.5f, cx, cy + r * 1.5f, line);
                if (joystick) {
                    c.drawCircle(cx, cy, radius, line);
                }
            }
        }
    }
}
