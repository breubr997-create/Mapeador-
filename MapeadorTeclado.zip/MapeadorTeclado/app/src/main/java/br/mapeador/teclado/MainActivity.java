package br.mapeador.teclado;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private TextView status;
    private float d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        d = getResources().getDisplayMetrics().density;

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (20 * d);
        root.setPadding(p, p * 2, p, p);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Mapeador de Teclado e Mouse");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, p / 2, 0, p / 2);
        root.addView(status);

        root.addView(button("1. Ativar o serviço (Acessibilidade)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        }));

        root.addView(button("2. Abrir editor de mapeamento", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapperService s = MapperService.instance;
                if (s == null) {
                    Toast.makeText(MainActivity.this,
                            "Ative o serviço em Acessibilidade primeiro.", Toast.LENGTH_LONG).show();
                    return;
                }
                s.openEditor();
                moveTaskToBack(true);
            }
        }));

        root.addView(button("Ligar / desligar modo jogo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapperService s = MapperService.instance;
                if (s == null) {
                    Toast.makeText(MainActivity.this,
                            "Ative o serviço em Acessibilidade primeiro.", Toast.LENGTH_LONG).show();
                    return;
                }
                s.setGameMode(!s.gameMode);
                refresh();
            }
        }));

        root.addView(button("Apagar todos os mapeamentos", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapperService s = MapperService.instance;
                if (s != null) {
                    s.maps.clear();
                    MappingStore.save(MainActivity.this, s.maps);
                } else {
                    MappingStore.save(MainActivity.this, new java.util.ArrayList<Mapping>());
                }
                refresh();
            }
        }));

        TextView help = new TextView(this);
        help.setTextSize(14);
        help.setPadding(0, p, 0, 0);
        help.setText(
                "Como usar\n\n"
                + "• Conecte o teclado/mouse por USB-OTG ou Bluetooth.\n"
                + "• Ative o serviço \"Mapeador Teclado e Mouse\" em Acessibilidade. "
                + "Um botão flutuante \"KM\" aparece na tela.\n"
                + "• Abra o jogo. Segure o botão KM por 1 segundo para abrir o editor: "
                + "toque onde fica cada botão do jogo e pressione a tecla (ou botão lateral "
                + "do mouse) que vai acioná-lo. Para andar, use o tipo JOYSTICK e informe "
                + "as 4 teclas (ex.: W, A, S, D).\n"
                + "• Toque no KM (ou aperte F8) para ligar/desligar o modo jogo. "
                + "Enquanto estiver ligado, as teclas mapeadas viram toques.\n\n"
                + "Limitações desta versão\n\n"
                + "• Cliques esquerdo/direito e movimento do mouse não são interceptados "
                + "(o Android não permite isso a um serviço de acessibilidade sem root/ADB). "
                + "Os botões laterais do mouse (voltar/avançar) funcionam como teclas.\n"
                + "• Latência de cerca de 50 ms por tecla.\n"
                + "• Os mapeamentos valem para a orientação de tela em que foram criados.");
        root.addView(help);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        MapperService s = MapperService.instance;
        if (s == null) {
            status.setText("Serviço: DESATIVADO");
            status.setTextColor(0xFFC62828);
        } else {
            List<Mapping> list = s.maps;
            status.setText("Serviço: ATIVO  •  Mapeamentos: " + list.size()
                    + "  •  Modo jogo: " + (s.gameMode ? "LIGADO" : "desligado"));
            status.setTextColor(0xFF2E7D32);
        }
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (8 * d);
        b.setLayoutParams(lp);
        return b;
    }
}
